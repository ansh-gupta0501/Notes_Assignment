
export function sayHello(){

    console.log('Hello welcome to reusablefunction')
}

export function getDataFromDatabase(name){
    // database command 
    return {'name' : name}
}

